INSTRUCTION:

LANCEMENT:
	Pour lancer le jeu double cliquez sur le fichier "colletonpoint.exe"

EN JEU:
	1| Cliquez sur 'Start' pour lancer le chronom�tre
	2| Cliquez sur l'image pour poser les gommettes
	3| Quand vous avez recouvert toutes les t�tes cliquez sur 'Stop'
	4| Recommencez si vous avez envie d'am�liorer votre score en appuyant sur 'Reset'
	5| Pour fermer la fen�tre appuyer sur 'Quitter'
	
PARTAGEZ VOTRE SCORE:
	Pour partagez votre score faites une capture d'�cran (touche 'Impr �cran' sur PC) et postez la sur
	Twitter avec #ColleTonPoint